select birth from people where name = "Emma Stone";
