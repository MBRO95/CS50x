select title, year from movies where title like "Harry Potter%" order by year asc;
