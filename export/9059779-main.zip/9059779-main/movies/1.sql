select title from movies where year = 2008;
