select count(movie_id) from ratings where rating = 10;
