select title from movies where year >= 2018 order by title asc;
