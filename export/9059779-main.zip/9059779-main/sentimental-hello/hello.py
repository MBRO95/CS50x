# Retrieve input from user and store it in a variable called name
name = input("What is your name?\n")
# Print some constant text along with the dynamically provided name variable
print("Hello, " + name)
