select name from songs order by tempo asc;
