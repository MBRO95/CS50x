select avg(energy) from songs;
